# Attack is the best defence.
