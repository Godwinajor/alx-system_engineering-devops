# 0x06. Regular Expression

## Resources:books:
Read or watch:
* [Regular expressions - basics](https://www.slideshare.net/neha_jain/introducing-regular-expressions)
* [Regular expressions - advanced](https://www.slideshare.net/neha_jain/advanced-regular-expressions-80296518)

---

### [0. simply_match_holberton](./0-simply_match_holberton.rb)

### [1. Repetion Token](./1-repetition_token_0.rb)

### [2. Repetion Token 2](./2-repetition_token_1.rb)

### [3. Repetion Token 3](./3-repetition_token_2.rb)

### [4. Repetion Token 4](./4-repetition_token_3.rb)

### [5. Not quite HBTN yet](./5-beginning_and_end.rb)

### [6. Call me maybe ](./6-phone_number.rb)

### [7. OMG WHY ARE YOU SHOUTING?](./7-OMG_WHY_ARE_YOU_SHOUTING.rb)

---

## Author
* **Joseph Mahiuha** - [Mahiuha](https://github.com/Mahiuha)

-----


