A simple shell redirections 
